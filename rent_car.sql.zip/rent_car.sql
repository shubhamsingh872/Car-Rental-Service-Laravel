-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2020 at 03:40 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rent_car`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `status`) VALUES
(1, 'admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `car_inventories`
--

CREATE TABLE `car_inventories` (
  `car_id` bigint(20) UNSIGNED NOT NULL,
  `car_reg_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `car_make` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `car_model` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mileage` int(11) NOT NULL,
  `transmission` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `car_type` int(11) NOT NULL,
  `fuel_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `def_location` int(11) NOT NULL,
  `passengers` int(11) NOT NULL,
  `doors` int(11) NOT NULL,
  `bags` int(11) NOT NULL,
  `car_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `available` int(11) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `car_inventories`
--

INSERT INTO `car_inventories` (`car_id`, `car_reg_no`, `car_make`, `car_model`, `mileage`, `transmission`, `car_type`, `fuel_type`, `def_location`, `passengers`, `doors`, `bags`, `car_image`, `available`, `status`, `created_at`, `updated_at`) VALUES
(1, 'HH01TH5624', 'Maruti', 'Maruti 800', 12, 'manual', 1, 'petrol', 1, 4, 4, 2, '97063695twitterp.png', 1, 1, '2020-11-27 06:35:34', '2020-11-27 07:44:17'),
(2, 'HH01TH5624', 'BMW', 'X5', 9, 'auto', 216, 'diesel', 1, 6, 4, 4, '1819612905.png', 1, 1, '2020-11-28 06:41:25', '2020-11-28 06:41:25'),
(3, 'HH01TH5600', 'AUDI', 'X3', 10, 'auto', 218, 'diesel', 1, 4, 4, 4, '1638196930.png', 1, 1, '2020-12-03 06:12:11', '2020-12-03 06:12:11'),
(4, 'HH01TH5600', 'AUDI', 'X3', 10, 'auto', 218, 'diesel', 1, 4, 4, 4, '1933035035.png', 1, 1, '2020-12-03 06:13:21', '2020-12-03 06:13:21'),
(5, 'HH01TH1256', 'AUDI', 'X6', 11, 'auto', 216, 'diesel', 1, 4, 4, 4, '1952041405.png', 1, 1, '2020-12-03 06:15:02', '2020-12-03 06:15:02');

-- --------------------------------------------------------

--
-- Table structure for table `car_types`
--

CREATE TABLE `car_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `extras` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price_per_day` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `price_per_hour` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `car_types`
--

INSERT INTO `car_types` (`id`, `name`, `description`, `extras`, `price_per_day`, `price_per_hour`, `created_at`, `updated_at`) VALUES
(1, 'Quos.', 'A.', 'Sit quod.', '4', '8', NULL, NULL),
(2, 'Est.', 'Quasi.', 'Nesciunt.', '2', '1', NULL, NULL),
(3, 'Enim.', 'Animi.', 'Est quia.', '6', '9', NULL, NULL),
(4, 'Quos.', 'Saepe.', 'Nam minima.', '7', '8', NULL, NULL),
(5, 'Nemo.', 'Sunt.', 'Mollitia.', '2', '8', NULL, NULL),
(6, 'Quam.', 'Beatae.', 'Aliquid.', '6', '7', NULL, NULL),
(7, 'Ab.', 'Libero.', 'Nostrum.', '9', '4', NULL, NULL),
(8, 'Hic.', 'Quia.', 'Inventore.', '8', '6', NULL, NULL),
(9, 'Et.', 'Est.', 'Dolorem.', '7', '0', NULL, NULL),
(10, 'Non.', 'Eum.', 'Numquam.', '0', '7', NULL, NULL),
(11, 'Ex.', 'Quod.', 'Autem.', '1', '2', NULL, NULL),
(12, 'Ut.', 'Beatae.', 'Dolorem.', '1', '3', NULL, NULL),
(13, 'Quia.', 'Est.', 'Ea.', '5', '0', NULL, NULL),
(14, 'Odit.', 'Quis.', 'Ad culpa.', '2', '2', NULL, NULL),
(15, 'Id.', 'Sunt.', 'Velit.', '7', '5', NULL, NULL),
(16, 'Aut.', 'Magni.', 'Hic eos qui.', '7', '1', NULL, NULL),
(17, 'Ea.', 'Nulla.', 'Voluptates.', '7', '5', NULL, NULL),
(18, 'Quo.', 'Sequi.', 'Dignissimos.', '3', '0', NULL, NULL),
(19, 'Non.', 'Ea aut.', 'Aperiam.', '3', '6', NULL, NULL),
(20, 'A.', 'Et.', 'Consequatur.', '4', '2', NULL, NULL),
(21, 'Sunt.', 'Beatae.', 'Nemo.', '4', '6', NULL, NULL),
(22, 'Qui.', 'Quam.', 'Culpa.', '6', '2', NULL, NULL),
(23, 'Aut.', 'Non.', 'Consequatur.', '9', '8', NULL, NULL),
(24, 'Ut.', 'Saepe.', 'Et.', '8', '5', NULL, NULL),
(25, 'Quam.', 'A.', 'Eos.', '1', '7', NULL, NULL),
(26, 'Eos.', 'Sunt.', 'Quia ut ut.', '0', '1', NULL, NULL),
(27, 'Sit.', 'Animi.', 'Similique.', '2', '0', NULL, NULL),
(28, 'Qui.', 'In.', 'Velit.', '1', '3', NULL, NULL),
(29, 'Qui.', 'Nihil.', 'Quod iste.', '6', '7', NULL, NULL),
(30, 'Et.', 'Qui.', 'Esse fugit.', '2', '1', NULL, NULL),
(31, 'Aut.', 'Id in.', 'Magni qui.', '1', '8', NULL, NULL),
(32, 'Qui.', 'In.', 'Rem tempora.', '1', '2', NULL, NULL),
(33, 'Qui.', 'Sed.', 'Dolorum.', '1', '6', NULL, NULL),
(34, 'Quod.', 'Amet.', 'Officiis.', '0', '2', NULL, NULL),
(35, 'Et.', 'Minus.', 'Doloribus.', '0', '8', NULL, NULL),
(36, 'Ad.', 'Quae.', 'Harum illum.', '9', '2', NULL, NULL),
(37, 'Quis.', 'Eius.', 'Sed.', '5', '6', NULL, NULL),
(38, 'Est.', 'Et.', 'Facere.', '1', '0', NULL, NULL),
(39, 'Hic.', 'Quis.', 'Voluptas.', '0', '4', NULL, NULL),
(40, 'Est.', 'Aut.', 'Hic et.', '4', '3', NULL, NULL),
(41, 'Qui.', 'Labore.', 'Autem.', '0', '8', NULL, NULL),
(42, 'Eius.', 'Ullam.', 'Nam.', '9', '9', NULL, NULL),
(43, 'Et.', 'Est.', 'Nesciunt.', '3', '9', NULL, NULL),
(44, 'Unde.', 'Non.', 'Natus.', '2', '7', NULL, NULL),
(45, 'Sit.', 'Aut.', 'Harum nihil.', '3', '9', NULL, NULL),
(46, 'Est.', 'Sed in.', 'Fugit.', '3', '5', NULL, NULL),
(47, 'Et.', 'Quis.', 'Qui tempora.', '9', '3', NULL, NULL),
(48, 'Cum.', 'Aut.', 'Et quia et.', '5', '9', NULL, NULL),
(49, 'Est.', 'Illum.', 'Facere.', '5', '3', NULL, NULL),
(50, 'Qui.', 'Earum.', 'Ullam.', '5', '8', NULL, NULL),
(51, 'Ea.', 'Alias.', 'Ut.', '8', '6', NULL, NULL),
(52, 'Aut.', 'Et.', 'Cum odit.', '5', '4', NULL, NULL),
(53, 'Id.', 'Quod.', 'Et est eos.', '4', '5', NULL, NULL),
(54, 'Quae.', 'Non.', 'Hic.', '5', '5', NULL, NULL),
(55, 'Esse.', 'Velit.', 'Possimus.', '8', '7', NULL, NULL),
(56, 'Quia.', 'Unde.', 'Sunt alias.', '3', '1', NULL, NULL),
(57, 'Ad.', 'In aut.', 'Et ea.', '9', '2', NULL, NULL),
(58, 'Odio.', 'Sint.', 'Est vero.', '3', '0', NULL, NULL),
(59, 'Eum.', 'Natus.', 'Eos sint.', '4', '9', NULL, NULL),
(60, 'Est.', 'Rerum.', 'Aut eos.', '0', '7', NULL, NULL),
(61, 'Illo.', 'Nihil.', 'Dignissimos.', '7', '1', NULL, NULL),
(62, 'Vel.', 'Sit.', 'Non facere.', '4', '9', NULL, NULL),
(63, 'Qui.', 'Optio.', 'Eaque.', '5', '7', NULL, NULL),
(64, 'Quia.', 'Alias.', 'Quaerat.', '3', '6', NULL, NULL),
(65, 'Non.', 'Autem.', 'Aut tempora.', '9', '7', NULL, NULL),
(66, 'Id.', 'Sit.', 'Rerum quia.', '2', '2', NULL, NULL),
(67, 'A ad.', 'Sit.', 'Illo.', '0', '0', NULL, NULL),
(68, 'Vel.', 'Quod.', 'Molestias.', '7', '9', NULL, NULL),
(69, 'Et.', 'Nisi.', 'Nemo dicta.', '7', '6', NULL, NULL),
(70, 'Vero.', 'Dolor.', 'Dignissimos.', '1', '2', NULL, NULL),
(71, 'Quia.', 'Iste.', 'Magnam unde.', '1', '1', NULL, NULL),
(72, 'Esse.', 'Ut.', 'Rerum.', '1', '0', NULL, NULL),
(73, 'Eius.', 'Libero.', 'Non.', '9', '1', NULL, NULL),
(74, 'Modi.', 'Nam.', 'Expedita.', '5', '6', NULL, NULL),
(75, 'Ab.', 'Dicta.', 'Et delectus.', '8', '1', NULL, NULL),
(76, 'Hic.', 'Ullam.', 'Sed maxime.', '8', '5', NULL, NULL),
(77, 'Qui.', 'Et.', 'Itaque.', '3', '5', NULL, NULL),
(78, 'Quia.', 'Quo.', 'Dolorum ab.', '9', '5', NULL, NULL),
(79, 'Ea.', 'Sequi.', 'Eos.', '4', '9', NULL, NULL),
(80, 'Esse.', 'Earum.', 'Odit porro.', '4', '5', NULL, NULL),
(81, 'Et.', 'Aut.', 'Expedita ad.', '7', '0', NULL, NULL),
(82, 'Est.', 'Est.', 'Velit esse.', '3', '4', NULL, NULL),
(83, 'Esse.', 'Est et.', 'Eos odio et.', '4', '7', NULL, NULL),
(84, 'A.', 'Ad et.', 'Quaerat ut.', '1', '4', NULL, NULL),
(85, 'Non.', 'Velit.', 'Sit ad.', '5', '2', NULL, NULL),
(86, 'Quis.', 'Est.', 'Eum non.', '8', '6', NULL, NULL),
(87, 'Id.', 'Sint.', 'Tempore.', '0', '1', NULL, NULL),
(88, 'Illo.', 'Eos.', 'Itaque.', '2', '7', NULL, NULL),
(89, 'Sunt.', 'Et.', 'Accusantium.', '5', '4', NULL, NULL),
(90, 'Aut.', 'Et.', 'Aut minus.', '0', '3', NULL, NULL),
(91, 'Odit.', 'Amet.', 'Aut.', '0', '9', NULL, NULL),
(92, 'Quam.', 'Omnis.', 'Iste.', '2', '6', NULL, NULL),
(93, 'Odit.', 'Omnis.', 'Sed nulla.', '3', '4', NULL, NULL),
(94, 'Quo.', 'Ipsum.', 'Modi qui.', '4', '1', NULL, NULL),
(95, 'Quia.', 'Ea.', 'Dicta et.', '6', '2', NULL, NULL),
(96, 'Et.', 'Omnis.', 'Omnis iusto.', '6', '1', NULL, NULL),
(97, 'Et.', 'Hic.', 'Alias ipsum.', '6', '5', NULL, NULL),
(98, 'Est.', 'Aut.', 'Repellendus.', '6', '5', NULL, NULL),
(99, 'Modi.', 'Et sit.', 'Rerum eos.', '6', '7', NULL, NULL),
(100, 'Qui.', 'Et.', 'Quod ab.', '8', '0', NULL, NULL),
(101, 'Sed.', 'Animi.', 'Distinctio.', '1', '7', NULL, NULL),
(102, 'Amet.', 'Ut.', 'Porro.', '5', '0', NULL, NULL),
(103, 'Quos.', 'Enim.', 'Nesciunt.', '4', '8', NULL, NULL),
(104, 'Qui.', 'Harum.', 'Nemo omnis.', '6', '4', NULL, NULL),
(105, 'Ex.', 'Est.', 'Consectetur.', '5', '7', NULL, NULL),
(106, 'Sunt.', 'Aut.', 'Sapiente id.', '4', '7', NULL, NULL),
(107, 'Aut.', 'Fuga.', 'Molestiae.', '8', '0', NULL, NULL),
(108, 'Qui.', 'Itaque.', 'Consequatur.', '3', '9', NULL, NULL),
(109, 'Hic.', 'Et aut.', 'Sit.', '1', '8', NULL, NULL),
(110, 'Ut.', 'Culpa.', 'Aspernatur.', '3', '2', NULL, NULL),
(111, 'Ut.', 'Dolor.', 'Tenetur et.', '6', '6', NULL, NULL),
(112, 'Ut.', 'Porro.', 'Atque.', '8', '3', NULL, NULL),
(113, 'Sit.', 'Eius.', 'Dolores.', '5', '5', NULL, NULL),
(114, 'Sit.', 'Ipsa.', 'Ut.', '4', '8', NULL, NULL),
(115, 'Illo.', 'Sed.', 'Iusto natus.', '2', '5', NULL, NULL),
(116, 'A.', 'Et.', 'Perferendis.', '6', '5', NULL, NULL),
(117, 'Ut.', 'Non.', 'Quaerat ut.', '7', '0', NULL, NULL),
(118, 'Et.', 'Et.', 'Ea.', '1', '9', NULL, NULL),
(119, 'Aut.', 'Ipsum.', 'Est quia.', '5', '5', NULL, NULL),
(120, 'Et.', 'Ea.', 'Corporis.', '7', '5', NULL, NULL),
(121, 'In.', 'Quae.', 'Hic.', '4', '3', NULL, NULL),
(122, 'Modi.', 'Omnis.', 'Facere nam.', '7', '2', NULL, NULL),
(123, 'Qui.', 'Aut.', 'Quo qui.', '0', '7', NULL, NULL),
(124, 'At.', 'Nemo.', 'Praesentium.', '0', '8', NULL, NULL),
(125, 'Qui.', 'Maxime.', 'Soluta sint.', '3', '3', NULL, NULL),
(126, 'Amet.', 'Nihil.', 'Iste.', '9', '1', NULL, NULL),
(127, 'Et.', 'Non.', 'Repellat id.', '8', '3', NULL, NULL),
(128, 'Eum.', 'Omnis.', 'Nemo.', '4', '6', NULL, NULL),
(129, 'Quae.', 'Non.', 'Suscipit.', '2', '3', NULL, NULL),
(130, 'Est.', 'Est.', 'Nemo sint.', '2', '7', NULL, NULL),
(131, 'Ea.', 'Quas.', 'Et aut.', '9', '6', NULL, NULL),
(132, 'Aut.', 'Culpa.', 'Expedita.', '6', '3', NULL, NULL),
(133, 'Eos.', 'Enim.', 'Debitis.', '7', '4', NULL, NULL),
(134, 'Non.', 'Rem.', 'Sit.', '2', '4', NULL, NULL),
(135, 'Ut a.', 'Qui.', 'Ut aliquam.', '6', '7', NULL, NULL),
(136, 'Qui.', 'Veniam.', 'Eos officia.', '4', '3', NULL, NULL),
(137, 'Ex.', 'Harum.', 'Quis.', '5', '0', NULL, NULL),
(138, 'Ut.', 'Qui.', 'Et.', '3', '5', NULL, NULL),
(139, 'Aut.', 'Ipsum.', 'Blanditiis.', '0', '2', NULL, NULL),
(140, 'Est.', 'Qui.', 'Doloremque.', '4', '7', NULL, NULL),
(141, 'Qui.', 'Iure.', 'Et.', '6', '0', NULL, NULL),
(142, 'Ea.', 'Et.', 'Recusandae.', '0', '0', NULL, NULL),
(143, 'A.', 'Ipsum.', 'Quia.', '6', '3', NULL, NULL),
(144, 'Illo.', 'Sequi.', 'Nesciunt.', '2', '1', NULL, NULL),
(145, 'Ex.', 'Qui.', 'Quia et.', '0', '0', NULL, NULL),
(146, 'Est.', 'Velit.', 'Et ut omnis.', '9', '4', NULL, NULL),
(147, 'Sunt.', 'Aut.', 'Debitis.', '1', '3', NULL, NULL),
(148, 'Et.', 'Aut et.', 'Dicta animi.', '5', '3', NULL, NULL),
(149, 'Et.', 'Eum.', 'Quis et.', '7', '4', NULL, NULL),
(150, 'Aut.', 'Qui.', 'Aut.', '9', '0', NULL, NULL),
(151, 'Sit.', 'Nihil.', 'Impedit.', '4', '9', NULL, NULL),
(152, 'Odit.', 'Fugiat.', 'Vel.', '1', '6', NULL, NULL),
(153, 'Quo.', 'Hic a.', 'Minima.', '5', '9', NULL, NULL),
(154, 'Illo.', 'Natus.', 'Dolorem.', '9', '7', NULL, NULL),
(155, 'Quod.', 'Eum.', 'Rerum.', '7', '6', NULL, NULL),
(156, 'Est.', 'Amet.', 'Cupiditate.', '9', '2', NULL, NULL),
(157, 'Amet.', 'Id aut.', 'Itaque.', '1', '5', NULL, NULL),
(158, 'Non.', 'Atque.', 'Culpa ipsum.', '8', '7', NULL, NULL),
(159, 'Sint.', 'Fugit.', 'Dolorem.', '8', '5', NULL, NULL),
(160, 'Quas.', 'Modi.', 'Eveniet.', '2', '3', NULL, NULL),
(161, 'Fuga.', 'Est.', 'Sint et qui.', '5', '9', NULL, NULL),
(162, 'Et.', 'Alias.', 'Laudantium.', '4', '8', NULL, NULL),
(163, 'Sed.', 'Quia.', 'Aspernatur.', '8', '7', NULL, NULL),
(164, 'Ut.', 'Porro.', 'Officia.', '9', '0', NULL, NULL),
(165, 'Quis.', 'Quam.', 'Esse.', '3', '2', NULL, NULL),
(166, 'Est.', 'Fuga.', 'Repudiandae.', '0', '5', NULL, NULL),
(167, 'Quod.', 'Omnis.', 'Ut.', '4', '3', NULL, NULL),
(168, 'In.', 'Non.', 'Veniam.', '3', '4', NULL, NULL),
(169, 'Eius.', 'Quia.', 'Animi eos.', '1', '1', NULL, NULL),
(170, 'Qui.', 'Sint.', 'Qui vitae.', '1', '1', NULL, NULL),
(171, 'Quas.', 'Modi.', 'Laborum sed.', '7', '8', NULL, NULL),
(172, 'Ut.', 'Cum.', 'Ab aut.', '8', '2', NULL, NULL),
(173, 'Et.', 'Qui.', 'Et magnam.', '8', '0', NULL, NULL),
(174, 'Vel.', 'Enim.', 'Et atque ea.', '5', '4', NULL, NULL),
(175, 'Aut.', 'Vero.', 'Quidem.', '4', '6', NULL, NULL),
(176, 'Quas.', 'At.', 'Omnis autem.', '0', '2', NULL, NULL),
(177, 'Et.', 'Ex.', 'Hic harum.', '5', '3', NULL, NULL),
(178, 'Hic.', 'Et.', 'Accusamus.', '6', '6', NULL, NULL),
(179, 'Qui.', 'Et.', 'Delectus.', '1', '0', NULL, NULL),
(180, 'Hic.', 'Ad.', 'Et nostrum.', '2', '3', NULL, NULL),
(181, 'Fuga.', 'Sunt.', 'Neque.', '9', '4', NULL, NULL),
(182, 'Sint.', 'Iusto.', 'Qui et.', '6', '8', NULL, NULL),
(183, 'Ut.', 'Veniam.', 'Qui.', '2', '8', NULL, NULL),
(184, 'Aut.', 'Hic.', 'Aut.', '5', '8', NULL, NULL),
(185, 'Ea.', 'Optio.', 'Itaque quia.', '6', '5', NULL, NULL),
(186, 'Aut.', 'Quos.', 'Sit animi.', '3', '6', NULL, NULL),
(187, 'Est.', 'Et.', 'Neque iusto.', '9', '3', NULL, NULL),
(188, 'Rem.', 'Omnis.', 'Qui vitae.', '6', '3', NULL, NULL),
(189, 'Odit.', 'Et.', 'Dolores ea.', '9', '1', NULL, NULL),
(190, 'Ipsa.', 'Aut.', 'Atque.', '4', '5', NULL, NULL),
(191, 'Iste.', 'Earum.', 'Vel.', '6', '8', NULL, NULL),
(192, 'Sed.', 'Optio.', 'Dolor est.', '1', '2', NULL, NULL),
(193, 'Quod.', 'Rerum.', 'Adipisci.', '8', '7', NULL, NULL),
(194, 'Ab.', 'Beatae.', 'Fuga.', '2', '8', NULL, NULL),
(195, 'Et.', 'Minus.', 'Explicabo.', '8', '4', NULL, NULL),
(196, 'Aut.', 'Eaque.', 'Illum qui.', '9', '0', NULL, NULL),
(197, 'Vel.', 'Et.', 'Aut.', '5', '1', NULL, NULL),
(198, 'Eos.', 'Animi.', 'Distinctio.', '7', '0', NULL, NULL),
(202, 'rtrtrtrt', 'fgdf gsdfgdfg', '12,14,15', '6', '6', '2020-11-11 08:16:23', '2020-11-11 08:16:23'),
(203, 'testing', 'dsfsd fsdf sadfs adfasd', '12,13', '9', '6', '2020-11-12 06:15:05', '2020-11-12 06:43:13'),
(204, 'sdfs fs df', 'dsf sd fsdfsd', NULL, '9', '7', '2020-11-21 09:13:40', '2020-11-21 09:13:40'),
(205, 'fdgfdg sdfg', 'sdf fgsdfgsfd', NULL, '9', '6', '2020-11-23 06:21:23', '2020-11-23 06:21:23'),
(206, 'sdf sdfsdf', 's dfsdfsadfsa', '2,14', '9', '7', '2020-11-23 06:21:53', '2020-11-23 06:21:53'),
(207, 'dsf sdfsadf', 'sdfsadfsad', '12,13', '9', '6', '2020-11-23 06:29:23', '2020-11-23 06:29:23'),
(208, 'dssf sd fsdf', 'sadfsadfsadf', '3,12', '9', '11', '2020-11-23 06:29:54', '2020-11-23 06:29:54'),
(209, 'dssf sd fsdf', 'sadfsadfsadf', '3,12', '9', '11', '2020-11-23 06:30:10', '2020-11-23 06:30:10'),
(210, 'sa sad sad', 'as dsad sgsdf', '2,12', '9', '6', '2020-11-23 06:31:40', '2020-11-23 06:31:40'),
(211, 'sa sad sad', 'as dsad sgsdf', '2,12', '9', '6', '2020-11-23 06:31:51', '2020-11-23 06:31:51'),
(212, 'sad sadsa', 'asdsadsada', NULL, '6', '7', '2020-11-23 06:33:02', '2020-11-23 06:33:02'),
(213, 'fg ss', 'sd fsaf', NULL, '7', '7', '2020-11-23 06:33:51', '2020-11-23 06:33:51'),
(214, 'dfg sgsdfsdf', 'asdfasdf afddsaf', NULL, '6', '6', '2020-11-23 06:35:22', '2020-11-23 06:35:22'),
(215, 'dsf sdfasad', 'asfasfsadfsad', NULL, '9', '8', '2020-11-23 06:39:47', '2020-11-23 06:39:47'),
(216, 'sadsa dsa', 'a sdsadsa', NULL, '9', '8', '2020-11-23 06:53:24', '2020-11-23 06:53:24'),
(217, 'd gsdfg', 'sdfgsdfgsdg', NULL, '9', '6', '2020-11-23 06:53:41', '2020-11-23 06:53:41'),
(218, 'dfgdf', 'dgdfgss', NULL, '9', '6', '2020-11-23 06:53:52', '2020-11-23 06:55:35');

-- --------------------------------------------------------

--
-- Table structure for table `extras`
--

CREATE TABLE `extras` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `duration` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `extras`
--

INSERT INTO `extras` (`id`, `name`, `price`, `duration`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Nisi.', 8, 'Dolor.', 'Ut.', NULL, NULL),
(2, 'Et.', 4, 'Ut.', 'Rem.', NULL, NULL),
(3, 'Vel.', 1, 'Dolor.', 'Aut.', NULL, NULL),
(12, 'dsfs sdfsdaf', 8, 'booking', 'single', '2020-11-11 07:19:13', '2020-11-11 07:19:13'),
(13, 'fdgfdgfdgdf sdgdfgdfg', 12, 'booking', 'single', '2020-11-11 07:19:37', '2020-11-11 07:19:37'),
(14, 'fhfghfg', 8, 'booking', 'single', '2020-11-11 07:31:44', '2020-11-11 07:31:44'),
(15, 'ghgd fghdghdh', 8, 'booking', 'single', '2020-11-23 06:59:58', '2020-11-23 07:00:23');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zipcode` int(11) NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `thumb` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `email`, `phone`, `address`, `zipcode`, `country`, `state`, `city`, `latitude`, `longitude`, `thumb`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Ewald Howe', 'cecil.haley@yahoo.com', '6', '788 Prosacco Drive Suite 721', 2, 'Kuwait', 'Kansas', 'Reingerton', '3.59601', '153.935292', 'Bridgette Jacobs', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2020_11_06_121735_create_car_types_table', 2),
(7, '2020_11_06_135404_create_extras_table', 3),
(8, '2020_11_18_132358_create_locations_table', 4),
(10, '2020_11_03_132213_create_car_inventories_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_inventories`
--
ALTER TABLE `car_inventories`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `car_types`
--
ALTER TABLE `car_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `extras`
--
ALTER TABLE `extras`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `car_inventories`
--
ALTER TABLE `car_inventories`
  MODIFY `car_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `car_types`
--
ALTER TABLE `car_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT for table `extras`
--
ALTER TABLE `extras`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
